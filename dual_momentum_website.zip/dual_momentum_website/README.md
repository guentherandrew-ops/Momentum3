# Dual Momentum Stock Screener Website

A Streamlit web app for screening stocks using dual momentum:

- 12-month absolute momentum
- 12-1 relative momentum
- 6-month return
- 200-day moving average filter
- benchmark-relative strength vs SPY or custom benchmark
- liquidity and price filters
- CSV download

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy on Streamlit Community Cloud

1. Create a GitHub repository.
2. Upload these files:
   - `app.py`
   - `requirements.txt`
   - `.streamlit/config.toml`
3. Go to Streamlit Community Cloud.
4. Click **New app**.
5. Select your GitHub repo.
6. Set the main file path to `app.py`.
7. Click **Deploy**.

## Deploy on Render

1. Create a new Web Service from a GitHub repo.
2. Use this build command:

```bash
pip install -r requirements.txt
```

3. Use this start command:

```bash
streamlit run app.py --server.port=$PORT --server.address=0.0.0.0
```

## Data note

This app uses Yahoo Finance data through `yfinance`. It is suitable for research/prototyping, not guaranteed production-grade trading data.
