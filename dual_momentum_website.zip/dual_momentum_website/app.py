from __future__ import annotations

import io
from dataclasses import dataclass
from typing import Iterable, List

import numpy as np
import pandas as pd
import streamlit as st
import yfinance as yf


# -----------------------------
# Config and universes
# -----------------------------
DEFAULT_SP100 = [
    "AAPL", "ABBV", "ABT", "ACN", "ADBE", "AIG", "AMD", "AMGN", "AMT", "AMZN",
    "AVGO", "AXP", "BA", "BAC", "BK", "BKNG", "BLK", "BMY", "BRK-B", "C",
    "CAT", "CHTR", "CL", "CMCSA", "COF", "COP", "COST", "CRM", "CSCO", "CVS",
    "CVX", "DE", "DHR", "DIS", "DUK", "EMR", "EXC", "F", "FDX", "GD",
    "GE", "GILD", "GM", "GOOG", "GOOGL", "GS", "HD", "HON", "IBM", "INTC",
    "INTU", "JNJ", "JPM", "KHC", "KO", "LIN", "LLY", "LMT", "LOW", "MA",
    "MCD", "MDLZ", "MDT", "MET", "META", "MMM", "MO", "MRK", "MS", "MSFT",
    "NEE", "NFLX", "NKE", "NVDA", "ORCL", "PEP", "PFE", "PG", "PM", "PYPL",
    "QCOM", "RTX", "SBUX", "SCHW", "SO", "SPG", "T", "TGT", "TMO", "TMUS",
    "TSLA", "TXN", "UNH", "UNP", "UPS", "USB", "V", "VZ", "WFC", "WMT", "XOM"
]

ETF_DUAL_MOMENTUM = ["SPY", "VEU", "BND", "QQQ", "IWM", "TLT", "GLD", "VNQ"]
MEGA_CAP_TECH = ["AAPL", "MSFT", "NVDA", "AMZN", "META", "GOOGL", "AVGO", "TSLA", "AMD", "ORCL", "NFLX", "ADBE", "CRM", "PANW", "PLTR"]

UNIVERSE_PRESETS = {
    "S&P 100-style large caps": DEFAULT_SP100,
    "ETF momentum set": ETF_DUAL_MOMENTUM,
    "Mega-cap tech/growth": MEGA_CAP_TECH,
    "Custom list only": [],
}


@dataclass
class ScreenConfig:
    min_avg_dollar_volume: float = 10_000_000
    top_n: int = 25
    require_positive_absolute_momentum: bool = True
    require_above_200dma: bool = True
    min_price: float = 5.0
    benchmark: str = "SPY"


# -----------------------------
# Data utilities
# -----------------------------
def parse_ticker_text(raw: str) -> List[str]:
    if not raw.strip():
        return []
    tokens = raw.replace("\n", ",").replace(";", ",").split(",")
    clean = []
    for t in tokens:
        x = t.strip().upper()
        if x:
            clean.append(x)
    # preserve order, drop duplicates
    return list(dict.fromkeys(clean))


def normalize_yf_ticker(ticker: str) -> str:
    # yfinance typically expects BRK-B instead of BRK.B in user-entered lists
    return ticker.replace(".", "-")


@st.cache_data(show_spinner=False, ttl=60 * 60)
def download_market_data(tickers: Iterable[str], period: str = "18mo") -> pd.DataFrame:
    tickers = [normalize_yf_ticker(t) for t in tickers]
    tickers = list(dict.fromkeys([t for t in tickers if t]))
    if not tickers:
        raise ValueError("No tickers provided.")

    data = yf.download(
        tickers=tickers,
        period=period,
        auto_adjust=True,
        progress=False,
        group_by="column",
        threads=True,
    )
    if data.empty:
        raise ValueError("No data returned from Yahoo Finance.")
    return data


def _safe_last(series: pd.Series) -> float:
    s = series.dropna()
    return float(s.iloc[-1]) if not s.empty else np.nan


def _return_over_lookback(series: pd.Series, lookback_days: int) -> float:
    s = series.dropna()
    if len(s) <= lookback_days:
        return np.nan
    start = s.iloc[-lookback_days - 1]
    end = s.iloc[-1]
    if pd.isna(start) or pd.isna(end) or start == 0:
        return np.nan
    return float(end / start - 1.0)


def _series_for(data: pd.DataFrame, field: str, ticker: str) -> pd.Series:
    if field not in data.columns.get_level_values(0):
        return pd.Series(dtype=float)
    try:
        return data[field][ticker].dropna()
    except Exception:
        return pd.Series(dtype=float)


def build_metrics(data: pd.DataFrame, tickers: Iterable[str], benchmark: str = "SPY") -> pd.DataFrame:
    rows = []
    benchmark = normalize_yf_ticker(benchmark)
    benchmark_close = _series_for(data, "Close", benchmark)
    benchmark_return_12m = _return_over_lookback(benchmark_close, 252)

    for ticker in tickers:
        ticker = normalize_yf_ticker(ticker)
        close = _series_for(data, "Close", ticker)
        volume = _series_for(data, "Volume", ticker)

        if close.empty or volume.empty:
            continue

        latest_price = _safe_last(close)
        ret_12m = _return_over_lookback(close, 252)
        ret_6m = _return_over_lookback(close, 126)
        ret_3m = _return_over_lookback(close, 63)
        ret_1m = _return_over_lookback(close, 21)

        mom_12_1 = np.nan
        if len(close) > 252:
            px_12m_ago = close.iloc[-253]
            px_1m_ago = close.iloc[-22] if len(close) > 21 else np.nan
            if pd.notna(px_12m_ago) and pd.notna(px_1m_ago) and px_12m_ago != 0:
                mom_12_1 = float(px_1m_ago / px_12m_ago - 1.0)

        ma_200 = float(close.tail(200).mean()) if len(close) >= 200 else np.nan
        above_200dma = bool(latest_price > ma_200) if pd.notna(ma_200) else False

        avg_dollar_volume_20d = np.nan
        if len(close) >= 20 and len(volume) >= 20:
            avg_dollar_volume_20d = float((close.tail(20) * volume.tail(20)).mean())

        rows.append(
            {
                "ticker": ticker,
                "price": latest_price,
                "return_12m": ret_12m,
                "return_6m": ret_6m,
                "return_3m": ret_3m,
                "return_1m": ret_1m,
                "momentum_12_1": mom_12_1,
                "ma_200": ma_200,
                "above_200dma": above_200dma,
                "avg_dollar_volume_20d": avg_dollar_volume_20d,
                "rs_vs_benchmark_12m": ret_12m - benchmark_return_12m if pd.notna(ret_12m) and pd.notna(benchmark_return_12m) else np.nan,
            }
        )

    df = pd.DataFrame(rows)
    if df.empty:
        raise ValueError("No usable ticker data found for the selected universe.")
    return df


def score_and_filter(metrics: pd.DataFrame, cfg: ScreenConfig) -> pd.DataFrame:
    df = metrics.copy()
    df = df[df["price"] >= cfg.min_price]
    df = df[df["avg_dollar_volume_20d"] >= cfg.min_avg_dollar_volume]

    if cfg.require_positive_absolute_momentum:
        df = df[df["return_12m"] > 0]

    if cfg.require_above_200dma:
        df = df[df["above_200dma"]]

    # Composite score emphasizes RS + 12-1 momentum + medium-term confirmation
    for col in ["rs_vs_benchmark_12m", "momentum_12_1", "return_6m", "return_3m"]:
        df[f"rank_{col}"] = df[col].rank(ascending=False, method="average")

    df["composite_score"] = (
        0.40 * (len(df) - df["rank_rs_vs_benchmark_12m"] + 1)
        + 0.35 * (len(df) - df["rank_momentum_12_1"] + 1)
        + 0.15 * (len(df) - df["rank_return_6m"] + 1)
        + 0.10 * (len(df) - df["rank_return_3m"] + 1)
    )

    df = df.sort_values(
        by=["composite_score", "rs_vs_benchmark_12m", "momentum_12_1"],
        ascending=False,
        na_position="last",
    ).head(cfg.top_n)

    return df.reset_index(drop=True)


def format_display(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    pct_cols = ["return_12m", "return_6m", "return_3m", "return_1m", "momentum_12_1", "rs_vs_benchmark_12m"]
    for col in pct_cols:
        if col in out.columns:
            out[col] = out[col].map(lambda x: f"{x:.1%}" if pd.notna(x) else "")

    if "price" in out.columns:
        out["price"] = out["price"].map(lambda x: f"{x:,.2f}" if pd.notna(x) else "")
    if "ma_200" in out.columns:
        out["ma_200"] = out["ma_200"].map(lambda x: f"{x:,.2f}" if pd.notna(x) else "")
    if "avg_dollar_volume_20d" in out.columns:
        out["avg_dollar_volume_20d"] = out["avg_dollar_volume_20d"].map(lambda x: f"{x:,.0f}" if pd.notna(x) else "")
    if "composite_score" in out.columns:
        out["composite_score"] = out["composite_score"].map(lambda x: f"{x:.1f}" if pd.notna(x) else "")
    return out


def to_csv_bytes(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False).encode("utf-8")


# -----------------------------
# App UI
# -----------------------------
st.set_page_config(page_title="Dual Momentum Screener", layout="wide")
st.title("Dual Momentum Screener")
st.caption("Ranks a stock or ETF universe using relative momentum, absolute momentum, and trend confirmation.")

with st.sidebar:
    st.header("Universe")
    preset = st.selectbox("Preset", list(UNIVERSE_PRESETS.keys()), index=0)
    custom_text = st.text_area(
        "Add custom tickers",
        value="AAPL, MSFT, NVDA, AMZN, META, GOOGL, AVGO, TSLA",
        height=110,
        help="Comma-separated tickers. These are combined with the preset unless you choose 'Custom list only'.",
    )
    custom_tickers = parse_ticker_text(custom_text)

    st.header("Filters")
    top_n = st.slider("Top results", min_value=5, max_value=100, value=25, step=5)
    min_price = st.slider("Minimum price", min_value=1.0, max_value=100.0, value=5.0, step=1.0)
    min_adv_millions = st.slider("Minimum avg dollar volume (20d, $MM)", min_value=0.0, max_value=100.0, value=10.0, step=1.0)
    require_abs = st.toggle("Require positive 12-month return", value=True)
    require_200dma = st.toggle("Require above 200-day moving average", value=True)
    benchmark = st.text_input("Benchmark ticker", value="SPY")
    run = st.button("Run screen", type="primary", use_container_width=True)

preset_tickers = UNIVERSE_PRESETS[preset]
universe = custom_tickers if preset == "Custom list only" else list(dict.fromkeys(preset_tickers + custom_tickers))

st.write(f"**Universe size:** {len(universe)} tickers")
if universe:
    st.code(", ".join(universe[:40]) + (" ..." if len(universe) > 40 else ""), language=None)
else:
    st.info("Add tickers in the sidebar to run the screen.")

cfg = ScreenConfig(
    min_avg_dollar_volume=min_adv_millions * 1_000_000,
    top_n=top_n,
    require_positive_absolute_momentum=require_abs,
    require_above_200dma=require_200dma,
    min_price=min_price,
    benchmark=benchmark.strip().upper() or "SPY",
)

if run:
    if not universe:
        st.error("No tickers selected.")
    else:
        all_tickers = list(dict.fromkeys([normalize_yf_ticker(t) for t in universe + [cfg.benchmark]]))
        with st.spinner("Downloading market data and ranking the universe..."):
            try:
                data = download_market_data(all_tickers)
                metrics = build_metrics(data, universe, benchmark=cfg.benchmark)
                results = score_and_filter(metrics, cfg)
            except Exception as e:
                st.exception(e)
            else:
                c1, c2, c3, c4 = st.columns(4)
                c1.metric("Candidates after filter", f"{len(results)}")
                c2.metric("Benchmark", cfg.benchmark)
                c3.metric("Min $ volume", f"${min_adv_millions:.0f}MM")
                c4.metric("Trend filter", "On" if cfg.require_above_200dma else "Off")

                st.subheader("Ranked results")
                display_cols = [
                    "ticker", "composite_score", "price", "return_12m", "momentum_12_1",
                    "rs_vs_benchmark_12m", "return_6m", "return_3m", "return_1m",
                    "above_200dma", "ma_200", "avg_dollar_volume_20d"
                ]
                view = format_display(results[display_cols]) if not results.empty else results
                st.dataframe(view, use_container_width=True, hide_index=True)

                st.download_button(
                    "Download CSV",
                    data=to_csv_bytes(results),
                    file_name="dual_momentum_screen.csv",
                    mime="text/csv",
                    use_container_width=True,
                )

                with st.expander("How the ranking works"):
                    st.markdown(
                        """
                        - **Absolute momentum:** optional requirement that 12-month total return is positive.
                        - **Trend filter:** optional requirement that price is above the 200-day moving average.
                        - **Relative strength:** compares each ticker's 12-month return to the chosen benchmark.
                        - **12-1 momentum:** trailing 12-month return excluding the most recent month.
                        - **Composite score:** weighted blend of benchmark-relative strength, 12-1 momentum, 6-month return, and 3-month return.
                        """
                    )

                with st.expander("Raw metrics"):
                    st.dataframe(metrics, use_container_width=True, hide_index=True)
